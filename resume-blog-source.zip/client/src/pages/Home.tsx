import { Mail, Linkedin, Github, ExternalLink, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Modern Academic Minimalism Resume Website
 * Design Philosophy: Clean, professional, information-focused
 * - Playfair Display for headings (elegant serif)
 * - Poppins for subheadings (modern sans-serif)
 * - Inter for body text (highly readable)
 * - Deep slate blue (#4B5563) as primary color
 * - Green accents for achievements
 */

export default function Home() {
  const heroBackgroundUrl = 'https://private-us-east-1.manuscdn.com/sessionFile/Phau9ipJIK2mlDdzwM2oiF/sandbox/xrU57serRHlCC376algjkm-img-1_1770257632000_na1fn_aGVyby1iYWNrZ3JvdW5k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUGhhdTlpcEpJSzJtbERkendNMm9pRi9zYW5kYm94L3hyVTU3c2VyUkhsQ0MzNzZhbGdqa20taW1nLTFfMTc3MDI1NzYzMjAwMF9uYTFmbl9hR1Z5YnkxaVlXTnJaM0p2ZFc1ay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=GvQibUnKWb1Lp0VGPrWgxlAzBn8kbHewQR3OD-KMoUjfaPD6c1T2d1-bMTvjYLnxNpwtYz5R1WistvRVNVzb3zTBYZqgpC~RyI6eJRe9xSnPdyE6sUW4RVDISwxGTlRmpsA551JksyK3bN8-KWEaWVKfvbdtTBlAachcN58A58bJavA2LI3nNI4bo8D4czhfG2qrIwJD7JtEuDOt0ytAIF8dU3-nd3UjrUtwAwyiEDCZO4AS99A4RfijvmVVs6yYOWYmgcUt6Ei6JdXkSbIeX7vk22alJ5OPAqFwl-y9NOHlg2YVH87VajDg39Q5PZ6DShF4NNeFEpGT425BB6JCOg__';

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-border shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="font-playfair text-2xl font-bold text-primary">
            Jia Guo
          </div>
          <div className="flex gap-8 items-center">
            <a href="#about" className="text-sm font-medium text-foreground hover:text-primary transition-colors">About</a>
            <a href="#research" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Research</a>
            <a href="#projects" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Projects</a>
            <a href="#skills" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Skills</a>
            <a href="#contact" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden"
        style={{
          backgroundImage: `url('${heroBackgroundUrl}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-white/10"></div>
        <div className="relative z-10 container text-center fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-6">
            Jia Guo
          </h1>
          <p className="text-xl md:text-2xl text-foreground mb-4 font-poppins font-medium">
            Computer Science Student & AI Research Enthusiast
          </p>
          <p className="text-lg text-foreground max-w-2xl mx-auto mb-8">
            Exploring uncertainty quantification and deep learning interpretability at UT Dallas AI Safety Lab
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button 
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Get In Touch
            </Button>
            <Button 
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Resume
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg text-foreground/80 leading-relaxed">
                I'm a senior Computer Science student at the University of Texas at Dallas with a passion for artificial intelligence and deep learning. My research focuses on uncertainty quantification and model interpretability in deep neural networks.
              </p>
              <p className="text-lg text-foreground/80 leading-relaxed">
                Currently, I'm working as an Undergraduate Research Assistant at the AI Safety Lab, contributing to projects that advance our understanding of how deep learning models make decisions and quantify their uncertainty.
              </p>
              <p className="text-lg text-foreground/80 leading-relaxed">
                Beyond research, I have hands-on experience in full-stack web development, cloud infrastructure, and algorithm design. I'm fluent in English and Mandarin Chinese.
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-8 border border-border">
              <h3 className="text-2xl font-bold text-primary mb-6">Quick Facts</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <div>
                    <p className="font-semibold text-foreground">Education</p>
                    <p className="text-foreground/70">B.S. Computer Science, UT Dallas (May 2026)</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <div>
                    <p className="font-semibold text-foreground">GPA</p>
                    <p className="text-foreground/70">3.4/4.0</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <div>
                    <p className="font-semibold text-foreground">Location</p>
                    <p className="text-foreground/70">Dallas, Texas, USA</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <div>
                    <p className="font-semibold text-foreground">Languages</p>
                    <p className="text-foreground/70">English (Fluent), Mandarin (Native)</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Research Section */}
      <section id="research" className="py-20">
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Research Experience</h2>
          <div className="space-y-8">
            <div className="experience-card">
              <h3 className="text-2xl font-bold text-primary mb-2">AI Safety Lab, UT Dallas</h3>
              <p className="text-foreground/70 font-poppins font-medium mb-4">
                Undergraduate Research Assistant | Advisor: Prof. Feng Chen
              </p>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex gap-3">
                  <span className="text-accent">→</span>
                  <span>Participated in "Multidimensional Uncertainty-Aware Deep Learning Framework" and "Hyper Evidential Deep Learning to Quantify Composite Classification Uncertainty" (ICLR 2024)</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-accent">→</span>
                  <span>Contributed visual datasets and proposed methods to improve model interpretability and uncertainty quantification</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-accent">→</span>
                  <span>Provided written feedback to refine experimental clarity and documentation</span>
                </li>
              </ul>
              <div className="mt-4 flex gap-2 flex-wrap">
                <span className="skill-tag-accent">Deep Learning</span>
                <span className="skill-tag-accent">Uncertainty Quantification</span>
                <span className="skill-tag-accent">Computer Vision</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-secondary/30">
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Project 1 */}
            <div className="card-minimal">
              <h3 className="text-2xl font-bold text-primary mb-2">Sorting Algorithms Implementation</h3>
              <p className="text-foreground/70 font-poppins text-sm mb-4">C++ Personal Project | 2025</p>
              <p className="text-foreground/80 mb-4">
                Implemented Quick Sort, Merge Sort, Insertion Sort, and Selection Sort with comprehensive performance analysis.
              </p>
              <ul className="space-y-2 text-foreground/80 text-sm mb-4">
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Analyzed algorithm performance by varying input size and time complexity</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Visualized performance metrics and comparison charts</span>
                </li>
              </ul>
              <div className="flex gap-2 flex-wrap">
                <span className="skill-tag">C++</span>
                <span className="skill-tag">Algorithms</span>
                <span className="skill-tag">Data Structures</span>
              </div>
            </div>

            {/* Project 2 */}
            <div className="card-minimal">
              <h3 className="text-2xl font-bold text-primary mb-2">Flight Planner System</h3>
              <p className="text-foreground/70 font-poppins text-sm mb-4">Java Personal Project | 2025</p>
              <p className="text-foreground/80 mb-4">
                Developed a flight planning system to find optimal routes by cost or time using backtracking and graph algorithms.
              </p>
              <ul className="space-y-2 text-foreground/80 text-sm mb-4">
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Applied recursion and object-oriented programming</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Implemented adjacency list structures for graph representation</span>
                </li>
              </ul>
              <div className="flex gap-2 flex-wrap">
                <span className="skill-tag">Java</span>
                <span className="skill-tag">Graph Algorithms</span>
                <span className="skill-tag">Backtracking</span>
              </div>
            </div>

            {/* Project 3 */}
            <div className="card-minimal">
              <h3 className="text-2xl font-bold text-primary mb-2">USCIC Official Website</h3>
              <p className="text-foreground/70 font-poppins text-sm mb-4">Web Developer | Jan 2024 - Jan 2025</p>
              <p className="text-foreground/80 mb-4">
                Developed and deployed the official U.S. Chinese Immigrants Center website using WordPress and AWS infrastructure.
              </p>
              <ul className="space-y-2 text-foreground/80 text-sm mb-4">
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Deployed on AWS (EC2, S3, RDS)</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Optimized site usability and managed ongoing maintenance</span>
                </li>
              </ul>
              <div className="flex gap-2 flex-wrap">
                <span className="skill-tag">WordPress</span>
                <span className="skill-tag">AWS</span>
                <span className="skill-tag">Web Development</span>
              </div>
            </div>

            {/* Project 4 */}
            <div className="card-minimal">
              <h3 className="text-2xl font-bold text-primary mb-2">Professional Experience</h3>
              <p className="text-foreground/70 font-poppins text-sm mb-4">3Catea - Deputy Store Manager | Jun 2024 - Aug 2024</p>
              <p className="text-foreground/80 mb-4">
                Supervised a team of 5, managed inventory systems, and improved customer satisfaction metrics.
              </p>
              <ul className="space-y-2 text-foreground/80 text-sm mb-4">
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Improved customer satisfaction by 5%</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✓</span>
                  <span>Enhanced team productivity through effective scheduling</span>
                </li>
              </ul>
              <div className="flex gap-2 flex-wrap">
                <span className="skill-tag">Leadership</span>
                <span className="skill-tag">Management</span>
                <span className="skill-tag">Problem Solving</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Technical Skills</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold text-primary mb-4">Programming Languages</h3>
              <div className="flex flex-wrap gap-2">
                <span className="skill-tag">C++</span>
                <span className="skill-tag">Java</span>
                <span className="skill-tag">Python</span>
                <span className="skill-tag">C</span>
                <span className="skill-tag">UNIX</span>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold text-primary mb-4">Tools & Platforms</h3>
              <div className="flex flex-wrap gap-2">
                <span className="skill-tag">AWS</span>
                <span className="skill-tag">EC2</span>
                <span className="skill-tag">S3</span>
                <span className="skill-tag">RDS</span>
                <span className="skill-tag">Route 53</span>
                <span className="skill-tag">WordPress</span>
                <span className="skill-tag">Git</span>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold text-primary mb-4">Areas of Expertise</h3>
              <div className="flex flex-wrap gap-2">
                <span className="skill-tag-accent">Deep Learning</span>
                <span className="skill-tag-accent">Computer Vision</span>
                <span className="skill-tag-accent">Algorithm Design</span>
                <span className="skill-tag-accent">Database Systems</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Honors & Certificates */}
      <section className="py-20 bg-secondary/30">
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Honors & Certificates</h2>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 rounded-lg border border-border hover:border-primary/30 transition-colors">
              <div className="text-accent text-2xl mt-1">★</div>
              <div>
                <p className="font-semibold text-foreground">Certificate of Participation</p>
                <p className="text-foreground/70">Multidimensional Uncertainty-Aware Deep Learning Framework — UT Dallas AI Safety Lab, Sep 2024</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-lg border border-border hover:border-primary/30 transition-colors">
              <div className="text-accent text-2xl mt-1">★</div>
              <div>
                <p className="font-semibold text-foreground">Languages</p>
                <p className="text-foreground/70">English (Fluent) • Mandarin Chinese (Native)</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-primary mb-6">Let's Connect</h2>
          <p className="text-lg text-foreground/80 mb-12 max-w-2xl mx-auto">
            I'm always interested in discussing AI research, web development opportunities, or just connecting with fellow tech enthusiasts.
          </p>
          <div className="flex gap-6 justify-center flex-wrap mb-12">
            <a 
              href="mailto:guoj1267@gmail.com"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors"
            >
              <Mail className="w-5 h-5" />
              Email
            </a>
            <a 
              href="https://www.linkedin.com/in/jia-guo-b26151290/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-primary text-primary hover:bg-primary/10 transition-colors"
            >
              <Linkedin className="w-5 h-5" />
              LinkedIn
            </a>
            <a 
              href="tel:832-439-1360"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-primary text-primary hover:bg-primary/10 transition-colors"
            >
              <ExternalLink className="w-5 h-5" />
              Call Me
            </a>
          </div>
          <p className="text-foreground/60 text-sm">
            Phone: 832-439-1360 | Email: guoj1267@gmail.com
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-secondary/50">
        <div className="container text-center text-foreground/60 text-sm">
          <p>© 2026 Jia Guo. All rights reserved. Built with React & Tailwind CSS.</p>
        </div>
      </footer>
    </div>
  );
}
